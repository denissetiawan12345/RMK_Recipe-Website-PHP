<?php
session_start();
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM login_user WHERE USERNAME = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($password === $row['PASSWORD']) {
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $row['GMAIL'];
            header("Location: index.php");
            exit();
        } else {
            $_SESSION['error_message_login'] = "Password salah.";
            header("Location: index.php");
            exit();
        }
    } else {
        $_SESSION['error_message_login'] = "Username tidak ditemukan.";
        header("Location: index.php");
        exit();
    }
}
?>
