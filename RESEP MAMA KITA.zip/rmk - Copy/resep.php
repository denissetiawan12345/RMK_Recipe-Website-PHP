<?php
include 'koneksi.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
<title>Resep Mama Kita -Temukan Resep Pilihan Anda</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="icon" href="images/logologo.png" type="image/png">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css" />
<script src="js/modernizer.js"></script>
<style>
    #owl-demo .item img{
  display: block;
  width: 100%;
  height: auto;
}
</style>
</head>

<body>
<audio id="audio" preload="auto">
  <source src="sound/tutorial.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    var audio = document.getElementById('audio');
    document.addEventListener("click", function() {
      if (!audio.paused || !audio.play) return;
      audio.play();
    });
  });
</script>
<div id="site-header">
        <header id="header" class="header-block-top">
        <div class="container">
                <div class="row">
                    <div class="main-menu">
                        <nav class="navbar navbar-default" id="mainNav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="logo">
                                    <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                        <img src="images/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                            <?php if(!isset($_SESSION['username'])) : ?>
    <a href="#" class="dropdown-toggle" data-toggle="dropdown"></a>
    <ul class="dropdown-menu dropdown-menu-right">
        <li>
                <form class="register-form" action="register.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    </div>
                    <?php
if(isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    echo '<div class="alert alert-danger">'.$error_message.'</div>';
    unset($_SESSION['error_message']);
}
?>
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
            <?php endif; ?>
        </li>
    </ul>
</li>
    </ul>
                                <ul class="nav navbar-nav navbar-right">
                                <?php if(isset($_SESSION['username'])) : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <img src="images/profil.png" alt="Profile Image" class="profile-image">
            <?php echo $_SESSION['username']; ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-right">
            <div class="text-col">
                <li class="dropdown-header">
                    <h3 style="color: #e75b1e">DASHBOARD USER</h3>
                    <h3 style="color: white; font-size: 20px;">Hello <?php echo $_SESSION['username']; ?></h3>
                    <p style="color: white">
                        <?php if(isset($_SESSION['email'])) : ?>
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <span>
                                <?php echo $_SESSION['email']; ?>
                            </span>
                        <?php endif; ?>
                    </p>
                </li>
                <li class="divider"></li>
                <li><a href="logout.php">Logout</a></li>
            </div>
        </ul>
    </li>
<?php else : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"></a>
        <ul class="dropdown-menu dropdown-menu-right">
            <li>
                <form class="login-form" action="login.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    </div>
                    <?php
                    if(isset($_SESSION['error_message_login'])) {
                        $error_message_login = $_SESSION['error_message_login'];
                        echo '<div class="alert alert-danger">'.$error_message_login.'</div>';
                        unset($_SESSION['error_message_login']);
                    }
                    ?>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </li>
        </ul>
    </li>
<?php endif; ?>

                                </ul>
                                <ul class="nav navbar-nav navbar-right">
                                    <li class="active"><a href="#resep">Resep</a></li>
                                    <li><a href="index.php">Beranda</a></li>
                                    <li><a href="#footer">Contact us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>

<img src="images/banner2.png" alt="banner" style="width: 100%; max-height: 400px; border-bottom: 100px;">
<div id="founders" class="team-main pad-top-100 pad-bottom-70 parallax">
<div class="container">
<h2 class="block-title color-white text-center"> Pilihan Resep Populer </h2>
<br>
    <div class="row">
        <?php
        $sql_resep = "SELECT * FROM resep";
        $result_resep = run_select_query($sql_resep);
        if (!empty($result_resep)) {
            foreach ($result_resep as $row) {
        ?>
        <div id="resep">
        <div class="col-md-3 col-sm-6">
                                <div class="sf-team" style="padding-bottom: 20px;">
                                    <div class="thumb">
                                        <a href="detail_makanan.php?nama_makanan=<?php echo urlencode($row['nama_makanan']); ?>"><img src="images//imgresep/<?php echo $row['gambar']; ?>" alt="gambar menu"></a>
                                    </div>
                                    <div class="text-col" style="height: 100px;">
                                        <h3><?php echo $row['nama_makanan']; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
        <?php
            }
        } else {
            echo "<div class='col-md-12'><p class='text-center'>Tidak ada resep yang ditemukan.</p></div>";
        }
        ?>
    </div>
</div>
</div>

<div id="footer" class="footer-main">
        <div class="footer-box pad-top-70 pad-bottom-100">
            <div class="container">
                <div class="row">
                    <div class="footer-in-main">
                        <div class="footer-logo">
                            <div class="text-center">
                                <img src="images/logo.png" alt="" />
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-a">
                                <h3>Tentang Kami</h3>
                                <p>Temukan kami di berbagai media social kami untuk mendapatkan informasi lebih lanjut.</p>
                                <ul class="socials-box footer-socials pull-left">
                                    <li>
                                        <a href="#">
                                            <div class="social-circle-border"><i class="fa  fa-facebook"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="social-circle-border"><i class="fa fa-twitter"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="social-circle-border"><i class="fa fa-google-plus"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="social-circle-border"><i class="fa fa-pinterest"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <div class="social-circle-border"><i class="fa fa-linkedin"></i></div>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-b">
                                <h3>Resep Terbaru</h3>
                                <ul>
                                    <li><a href="#">Nasi Goreng Seafood</a></li>
                                    <li><a href="#">Donat Kentang</a></li>
                                    <li><a href="#">Cah Kangkung</a></li>
                                    <li><a href="#">Telur Dadar</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-c">
                                <h3>Kontak kami</h3>
                                <p>
                                    <i class="fa fa-mobile" aria-hidden="true"></i>
                                    <span>
									+62 821 7923 6039
								</span>
                                </p>
                                <p>
                                    <span>
                                        WhatsApp <a href="https://wa.me/6282179236039"> Click Here</a>
                                    </span>
                                </p>
                                <p>
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    <span><a href="https://www.gmail.com" target="_blank">ventinitygt@gmail.com</a></span>
                                </p>
                                <h3>Special Credit</h3>
                                <p>
                                    <i class="fa fa-youtube" aria-hidden="true"></i>
                                    <span><a href="https://www.youtube.com/@devinahermawan" target="_blank">Devina Hermawan</a></span>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-d">
                                <h3>Copyright</h3>
                                <ul>
                                    <li>
                                        <p>OpenAi ChatGPT </p>
                                        <p>Cookpad</p>
                                        <p>Bootstrap</p>
                                        <p>W3School</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="js/all.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/custom.js"></script>
</body>

</html>