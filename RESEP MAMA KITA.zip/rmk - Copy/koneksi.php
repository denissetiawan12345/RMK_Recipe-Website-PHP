<?php

// Detail koneksi ke database
$host = "localhost"; // Ganti dengan host database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$database = "web.resepmamakita"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk menjalankan query select
function run_select_query($query) {
    global $conn;
    $result = $conn->query($query);
    $rows = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    }
    return $rows;
}

// Fungsi untuk menjalankan query insert, update, delete
function run_query($query) {
    global $conn;
    if ($conn->query($query) === TRUE) {
        return true;
    } else {
        return false;
    }
}

// Fungsi untuk membersihkan inputan
function sanitize_input($input) {
    global $conn;
    $input = trim($input);
    $input = mysqli_real_escape_string($conn, $input);
    return $input;
}

?>
