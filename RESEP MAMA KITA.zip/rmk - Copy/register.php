<?php
include 'koneksi.php';
session_start();

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Validasi format email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@.*\./', $email)) {
            $error_message = "Format email tidak valid. Harap gunakan format yang benar.";
        } elseif (strlen($password) < 8) {
            $error_message = "Password harus terdiri dari minimal 8 karakter.";
        } else {
            $check_query = "SELECT * FROM login_user WHERE USERNAME = '$username' OR GMAIL = '$email'";
            $result = run_select_query($check_query);

            if ($result) {
                $error_message = "Username atau email sudah digunakan. Silakan gunakan yang lain.";
            } else {
                $insert_query = "INSERT INTO login_user (USERNAME, GMAIL, PASSWORD) VALUES ('$username', '$email', '$password')";

                if (run_query($insert_query)) {
                    $_SESSION['username'] = $username;
                    $_SESSION['email'] = $email;
                    header("Location: index.php");
                    exit();
                } else {
                    $error_message = "Terjadi kesalahan saat melakukan registrasi. Silakan coba lagi.";
                }
            }
        }
    } else {
        $error_message = "Harap isi semua bidang.";
    }
}

// Mengirimkan kembali pesan kesalahan ke halaman utama dan mengarahkan kembali ke index.php
$_SESSION['error_message'] = $error_message;
header("Location: index.php");
exit();
?>
