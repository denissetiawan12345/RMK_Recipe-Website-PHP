<?php
include 'koneksi.php';
session_start();

if(isset($_GET['nama_makanan'])) {
    $nama_makanan = $_GET['nama_makanan'];
    $query_makanan = "SELECT * FROM resep WHERE nama_makanan = '$nama_makanan'";
    $result_makanan = run_select_query($query_makanan);

    if($result_makanan && count($result_makanan) > 0) {
        $row_makanan = $result_makanan[0];
        $nama_makanan = $row_makanan['nama_makanan'];
        $deskripsi = $row_makanan['deskripsi'];
        $gambar = $row_makanan['gambar'];
        $video = $row_makanan['video'];
        $query_bahan = "SELECT b.nama_bahan, rb.jumlah, rb.satuan FROM bahan b
                INNER JOIN resep_bahan rb ON b.id_bahan = rb.id_bahan
                WHERE rb.id_resep = " . $row_makanan['id_resep'];

$result_bahan = run_select_query($query_bahan);
        $query_alat = "SELECT a.nama_alat FROM alat a
                       INNER JOIN resep_alat ra ON a.id_alat = ra.id_alat
                       WHERE ra.id_resep = " . $row_makanan['id_resep'];
        $result_alat = run_select_query($query_alat);
        $query_langkah_masak = "SELECT langkah, waktu FROM langkah_masak WHERE id_resep = " . $row_makanan['id_resep'];
        $result_langkah_masak = run_select_query($query_langkah_masak);
        $query_nutrisi = "SELECT n.* FROM nutrisi n
                          INNER JOIN resep r ON n.id_resep = r.id_resep
                          WHERE r.id_resep = " . $row_makanan['id_resep'];
        $result_nutrisi = run_select_query($query_nutrisi);
    } else {
        $_SESSION['error_message'] = "Detail makanan tidak ditemukan.";
        header("Location: index.php");
        exit();
    }
} else {
    $_SESSION['error_message'] = "Parameter nama_makanan tidak diteruskan.";
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
<title>Resep Mama Kita -Temukan Resep Pilihan Anda</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content="">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="icon" href="images/logologo.png" type="image/png">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">
<link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css" />
<script src="js/modernizer.js"></script>

<style>
    body {
  font: 13px 'Open Sans', sans-serif;
  color: #fff;
}
.recipe-card {
  -webkit-box-shadow: 0px 0px 20px 1px rgba(10,10,10,1);
  -moz-box-shadow: 0px 0px 20px 1px rgba(10,10,10,1);
  box-shadow: 0px 0px 20px 1px rgba(10,10,10,1);
  border:1px solid #f0f1f3;
  width: 400px;
  height: auto;
  margin: 10px auto;
}
.recipe-card iframe {
        width: 100%;
        height: 520px;
        border: none;
        border-radius: 8px;
    }
.recipe-card__body {    
    padding: 20px;
}
.recipe-card__heading {
  padding: 0;
  margin: 0 0 0;
  color: #444;
}
.recipe-card__subhead {
  font-size: 13px;
  color: #555;
  margin-bottom: 30px;
}
.recipe-card__ingredients {
  list-style: none;
  margin: 0;
  padding: 0;
  margin-left: 10px;
  column-count: 1;
  li {
    margin-bottom: 5px;
  }
  li:before {
    content: '\2022';
    color: #eb9376;
    margin-right: 5px;
  }
}
.recipe-card__ingredients .darken-text {
    color: rgba(255, 255, 255, 0.6);
}

.recipe-card__nav {
  margin: 0 0 20px;
  padding: 0;
  border-bottom: 1px solid #eb9376;
  li {
    display: inline-block;
    margin-right: 30px
  }
  h3 {
    margin: 0;
    padding: 0;
  }
  h3:after {
    content: '';
    display: block;
    width: 0%;
    padding-top: 10px;
    margin: 0 auto;
    border-bottom: 5px solid #eb9376;
    transition: width 250ms ease-in-out 0s;
  }
  h3:hover {
    cursor: pointer;
  }
  h3:hover:after, h3.active:after {
   width: 100%; 
  }
}

@media (min-width:599px) {
  .recipe-card {
    width: 1100px
  }
  .recipe-card__ingredients {
    font-size: 15px;
    column-count: 2
  }
}
</style>

</head>

<body>
<div id="loader">
        <div id="status"></div>
    </div>
<div id="site-header">
        <header id="header" class="header-block-top">
        <div class="container">
                <div class="row">
                    <div class="main-menu">
                        <nav class="navbar navbar-default" id="mainNav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="logo">
                                    <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                        <img src="images/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                            <?php if(!isset($_SESSION['username'])) : ?>
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Register</a>
    <ul class="dropdown-menu dropdown-menu-right">
        <li>
                <form class="register-form" action="register.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    </div>
                    <?php
if(isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    echo '<div class="alert alert-danger">'.$error_message.'</div>';
    unset($_SESSION['error_message']);
}
?>
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
            <?php endif; ?>
        </li>
    </ul>
</li>
    </ul>
                                <ul class="nav navbar-nav navbar-right">
                                <?php if(isset($_SESSION['username'])) : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <img src="images/profil.png" alt="Profile Image" class="profile-image">
            <?php echo $_SESSION['username']; ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-right">
            <div class="text-col">
                <li class="dropdown-header">
                    <h3 style="color: #e75b1e">DASHBOARD USER</h3>
                    <h3 style="color: white; font-size: 20px;">Hello <?php echo $_SESSION['username']; ?></h3>
                    <p style="color: white">
                        <?php if(isset($_SESSION['email'])) : ?>
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <span>
                                <?php echo $_SESSION['email']; ?>
                            </span>
                        <?php endif; ?>
                    </p>
                </li>
                <li class="divider"></li>
                <li><a href="logout.php">Logout</a></li>
            </div>
        </ul>
    </li>
<?php else : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Login</a>
        <ul class="dropdown-menu dropdown-menu-right">
            <li>
                <form class="login-form" action="login.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    </div>
                    <?php
                    if(isset($_SESSION['error_message_login'])) {
                        $error_message_login = $_SESSION['error_message_login'];
                        echo '<div class="alert alert-danger">'.$error_message_login.'</div>';
                        unset($_SESSION['error_message_login']);
                    }
                    ?>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </li>
        </ul>
    </li>
<?php endif; ?>

                                </ul>
                                <ul class="nav navbar-nav navbar-right">
                                    <li class="active"><a href="#resep">Detail Makanan</a></li>
                                    <li><a href="#"></a></li>
                                    <li><a href="#video">Video Tutorial</a></li>
                                    <li><a href="#menu">Pilihan Menu</a></li>
                                    <li><a href="#footer">Contact us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>
 <img src="images/banner2.png" alt="banner" style="width: 100%; max-height: 400px; border-bottom: 100px;">
<div id=resep>
    <br>
<h2 class="block-title color-white text-center"> Detail Resep </h2>
 <div class='recipe-card'>
  <div style="background:url(images//imgresep/<?php echo $gambar; ?>) no-repeat 50% 50%; background-size:cover; height: 500px"></div>
  <div class="recipe-card__body">
    <h1 class="block-title color-white text-center"><?php echo $nama_makanan; ?></h1>
    <h2 class="title-caption text-center"><?php echo $deskripsi; ?></h2>
    
    <ul class="recipe-card__nav">
  <li>
    <h3 class="block-title color-white text-center" style="font-size: 35px;">Bahan-bahan</h3>
  </li>
</ul>
<ul class="recipe-card__ingredients">
<?php
foreach ($result_bahan as $bahan) {
    echo "<li>" . $bahan['jumlah'] . " " . $bahan['satuan'] . " " . $bahan['nama_bahan'] . "</li>";
}
?>
</ul>

<ul class="recipe-card__nav">
  <li>
    <h3 class="block-title color-white text-center" style="font-size: 35px; padding-top: 35px">Alat-alat</h3>
  </li>
</ul>
<ul class="recipe-card__ingredients">
<?php
foreach ($result_alat as $alat) {
    echo "<li>" . $alat['nama_alat'] . "</li>";
}
?>
</ul>

<ul class="recipe-card__nav">
  <li>
    <h3 class="block-title color-white text-center" style="font-size: 35px; padding-top: 35px;">Langkah Pembuatan</h3>
  </li>
</ul>

<ul class="recipe-card__ingredients">
<?php
foreach ($result_langkah_masak as $langkah) {
    echo "<li>" . $langkah['langkah'] . " <span class='darken-text'>(Durasi: " . $langkah['waktu'] . ")</li>";
}
?>


</ul>
<ul class="recipe-card__nav">
  <li>
    <h3 class="block-title color-white text-center" style="font-size: 35px; padding-top: 100px;">Informasi Nutrisi</h3>
  </li>
</ul>
<ul class="recipe-card__ingredients">
<?php
if ($result_nutrisi && count($result_nutrisi) > 0) {
    foreach ($result_nutrisi as $nutrisi) {
        echo "<li>Kalori: " . $nutrisi['kalori'] . " kcal</li>";
        echo "<li>Protein: " . $nutrisi['protein'] . " gram</li>";
        echo "<li>Lemak: " . $nutrisi['lemak'] . " gram</li>";
        echo "<li>Karbohidrat: " . $nutrisi['karbohidrat'] . " gram</li>";
        echo "<li>Serat: " . $nutrisi['serat'] . " gram</li>";
        echo "<li>Gula: " . $nutrisi['gula'] . " gram</li>";
        echo "<li>Natrium: " . $nutrisi['natrium'] . " mg</li>";
    }
} else {
    echo "<li>Informasi nutrisi tidak tersedia.</li>";
}
?>
</ul>




  </div>
</div>
<div id="video">
    <br>
    <h2 class="block-title color-white text-center pad-top-100">Video Masak</h2>
    <div class='recipe-card'>
    <iframe width="560" height="620" src="<?php echo $video; ?>" frameborder="0" allowfullscreen></iframe>
    </div>
</div>



</div>
<div id="menu">
<div class=" pad-top-100 parallax">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                    <h2 class="block-title color-white text-center"> pilihan menu lainnya </h2>
                </div>
                <div class="special-box">
                    <div id="owl-demo">
                    <?php
$sql = "SELECT * FROM resep";
$result = run_select_query($sql);

if (!empty($result)) {
foreach ($result as $row) {
    ?>
    <div class="item item-type-zoom">
        <a href="detail_makanan.php?nama_makanan=<?php echo urlencode($row['nama_makanan']); ?>" class="item-hover">
            <div class="item-info">
                <div class="headline">
                    <?php echo $row['nama_makanan']; ?>
                    <div class="line"></div>
                    <div class="dit-line"><?php echo $row['deskripsi']; ?></div>
                </div>
            </div>
        </a>
        <div class="item-img">
            <img src="images//imgresep/<?php echo $row['gambar']; ?>" alt="sp-menu">
        </div>
    </div>
    <?php
}
} else {
echo "Tidak ada data resep yang ditemukan";
}
?>
                    </div>
                    <div class="book-btn" style="display: flex; justify-content: center;">
                        <a href="resep.php" class="table-btn hvr-underline-from-center">LIHAT SELENGKAPNYA</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div id="footer" class="footer-main">
        <div class="footer-box pad-top-70 pad-bottom-100">
            <div class="container">
                <div class="row">
                    <div class="footer-in-main">
                        <div class="footer-logo">
                            <div class="text-center">
                                <img src="images/logo.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-a">
                                <h3>Tentang Kami</h3>
                                <p>Temukan kami di berbagai media social kami untuk mendapatkan informasi lebih lanjut.</p>
                                <ul class="socials-box footer-socials pull-left">
                                    <li>
                                        <a href="https://www.facebook.com/profile.php?id=100028724352214" target="_blank">
                                            <div class="social-circle-border"><i class="fa  fa-facebook"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://api.whatsapp.com/send/?phone=%2B6285669530929&text&type=phone_number&app_absent=0" target="_blank">
                                            <div class="social-circle-border"><i class="fa fa-whatsapp"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/dennnis.s" target="_blank">
                                            <div class="social-circle-border"><i class="fa fa-instagram"></i></div>
                                        </a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="footer-box-b">
        <h3>Resep Terbaru</h3>
        <ul>
            <?php
            $resep = [
                ['nama_makanan' => 'Pasta', 'gambar' => '1.png'],
                    ['nama_makanan' => 'Nasi Goreng', 'gambar' => '2.png'],
                    ['nama_makanan' => 'Salad Buah', 'gambar' => '3.png'],
                    ['nama_makanan' => 'Rawon', 'gambar' => '4.png']
                    ];
                    foreach ($resep as $row) {
                    echo '<li><a href="detail_makanan.php?nama_makanan=' . urlencode($row['nama_makanan']) . '">' . $row['nama_makanan'] . '</a></li>';}?>
                    </ul>
                </div>
                    </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-c">
                                <h3>Kontak kami</h3>
                                <p>
                                    <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                    <span>
									<a href="https://wa.me/+6285669530929" target="_blank">+6285669530929</a>
								</span>
                                </p>
                                <p>
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                    <span><a href="https://www.gmail.com" target="_blank">ventinitygt@gmail.com</a></span>
                                </p>
                                <h3>Special Credit</h3>
                                <p>
                                    <i class="fa fa-youtube" aria-hidden="true"></i>
                                    <span><a href="https://www.youtube.com/@devinahermawan" target="_blank">Devina Hermawan</a></span>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-d">
                                <h3>Copyright</h3>
                                <ul>
                                    <li>
                                        <p>OpenAi ChatGPT </p>
                                        <p>Cookpad</p>
                                        <p>Bootstrap</p>
                                        <p>W3School</p>
                                        
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>