<!DOCTYPE html>
<html lang="en">
<?php
include 'koneksi.php';

session_start();
?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
    <title>Resep Mama Kita -Temukan Resep Pilihan Anda</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link id="changeable-colors" rel="stylesheet" href="css/colors/orange.css" />
    <script src="js/modernizer.js"></script>
    <link rel="icon" href="images/logologo.png" type="image/png">


</head>

<body>
<audio id="audio" preload="auto">
<source src="sound/tutorial.mp3" type="audio/mpeg">
Your browser does not support the audio element.
</audio>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var audio = document.getElementById('audio');
    document.addEventListener("click", function() {
        if (!audio.paused || !audio.play) return;
    audio.play();
    });
});
</script>





<div id="loader">
        <div id="status"></div>
    </div>
    <div id="site-header">
        <header id="header" class="header-block-top">
        <div class="container">
                <div class="row">
                    <div class="main-menu">
                        <nav class="navbar navbar-default" id="mainNav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="logo">
                                    <a class="navbar-brand js-scroll-trigger logo-header" href="index.php">
                                        <img src="images/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <?php if(!isset($_SESSION['username'])) : ?>
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Register</a>
    <ul class="dropdown-menu dropdown-menu-right">
        <li>
            <form class="register-form" action="register.php" method="post">
                <div class="form-group">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                </div>
                <?php
    if(isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    echo '<div class="alert alert-danger">'.$error_message.'</div>';
    unset($_SESSION['error_message']);}?>

                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                </form>
            <?php endif; ?>
        </li>
    </ul>
</li>
    </ul>
                                <ul class="nav navbar-nav navbar-right">
                                <?php if(isset($_SESSION['username'])) : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <img src="images/profil.png" alt="Profile Image" class="profile-image">
            <?php echo $_SESSION['username']; ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-right">
            <div class="text-col">
                <li class="dropdown-header">
                    <h3 style="color: #e75b1e">DASHBOARD USER</h3>
                    <h3 style="color: white; font-size: 20px;">Hello <?php echo $_SESSION['username']; ?></h3>
                    <p style="color: white">
                        <?php if(isset($_SESSION['email'])) : ?>
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                            <span>
                                <?php echo $_SESSION['email']; ?>
                            </span>
                        <?php endif; ?>
                    </p>
                </li>
                <li class="divider"></li>
                <li><a href="logout.php">Logout</a></li>
            </div>
        </ul>
    </li>
<?php else : ?>
    <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Login</a>
        <ul class="dropdown-menu dropdown-menu-right">
            <li>
                <form class="login-form" action="login.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    </div>
                    <?php
                    if(isset($_SESSION['error_message_login'])) {
                        $error_message_login = $_SESSION['error_message_login'];
                        echo '<div class="alert alert-danger">'.$error_message_login.'</div>';
                        unset($_SESSION['error_message_login']);
                    }
                    ?>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </li>
        </ul>
    </li>
<?php endif; ?>

                                </ul>
                                <ul class="nav navbar-nav navbar-right">
                                    <li class="active"><a href="#banner">Home</a></li>
                                    <li><a href="#about">About us</a></li>
                                    <li><a href="#menu">Menu</a></li>
                                    <li><a href="#founders">Founders</a></li>
                                    <li><a href="#footer">Contact us</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>
	
    <div id="banner" class="banner full-screen-mode parallax">
        <div class="container pr">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="banner-static">
                    <div class="banner-text">
                        <div class="banner-cell">
                            <h1>Mau Masak <span class="typer" id="some-id" data-delay="200" data-delim=":" data-words="Gorengan?:Rebusan?:Tumisan?" data-colors="red"></span><span class="cursor" data-cursorDisplay="_" data-owner="some-id"></span></h1>
                            <h2>Temukan Semuanya Di Resep Mama Kita </h2>
                            <p>Temukan resep terbaik seperti masakan ibu sendiri.</p>
                            <div class="book-btn">
                                <a href="#menu" class="table-btn hvr-underline-from-center">PILIHAN RESEP</a>
                            </div>
                            <a href="#about">
                                <div class="mouse"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="about" class="about-main pad-top-100 pad-bottom-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                        <h2 class="block-title"> About Us </h2>
                        <h3>Tentang Kami</h3>
                        <p> Resep Mama Kita Merupakan tempat di mana user dapat menemukan resep pilihanya dengan takaran saji dan nutrisi yang lengkap.</p>
                        <h3>Tujuan Kami</h3>
                        <p> Kami bercita cita mempermudah pengguna dalam memasak dan menyajikan informasi tentang apa saja yang di konsumsi oleh pengguna, kami dari itu besar harapan kami dalam menciptakan website yang user friendly dan menciptakan experience menarik bagi pengguna</p>

                        <p> Selamat memasak dan menyantap makanan anda, terima kasih</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                        <div class="about-images">
                            <img class="about-main" src="images/aboutmain.png" alt="About Main Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="menu">
    <div class="special-menu pad-top-100 parallax">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                        <h2 class="block-title color-white text-center"> Special Minggu Ini </h2>
                        <h5 class="title-caption text-center"></h5>
                    </div>
                    <div class="special-box">
                        <div id="owl-demo">

                        <?php
    $sql = "SELECT * FROM resep";
$result = run_select_query($sql);
if (!empty($result)) {
    foreach ($result as $row) {
        ?>

        <div class="item item-type-zoom">
            <a href="detail_makanan.php?nama_makanan=<?php echo urlencode($row['nama_makanan']); ?>" class="item-hover">
                <div class="item-info">
                    <div class="headline">
                        <?php echo $row['nama_makanan']; ?>
                        <div class="line"></div>
                        <div class="dit-line"><?php echo $row['deskripsi']; ?></div>
                    </div>
                </div>
            </a>
            <div class="item-img">
                <img src="images//imgresep/<?php echo $row['gambar']; ?>" alt="sp-menu">
            </div>
        </div>
        <?php
    }
} else {
    echo "Tidak ada data resep yang ditemukan";
}
?>
                        </div>
                        <div class="book-btn" style="display: flex; justify-content: center;">
                            <a href="resep.php" class="table-btn hvr-underline-from-center">LIHAT SELENGKAPNYA</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="founders" class="team-main pad-top-100 pad-bottom-70 parallax">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.1s">
                    <h2 class="block-title text-center">The Founders</h2>
                    <p class="title-caption text-center">Beberapa orang yang berkontribusi dalam pembuatan, pemeliharaan, serta pengoperasian situs website ini</p>
                </div>
                <div class="team-box">
                    <div class="row">
                        <?php
                        $query = "SELECT * FROM founder";
                        $founders = run_select_query($query);

                        if (!empty($founders)) {
                            foreach ($founders as $founder) {
                                ?>
                                <div class="col-md-3 col-sm-6">
    <div class="sf-team">
        <div class="thumb">
            <a href="#footer"><img src="images/<?php echo $founder['gambar_url']; ?>" alt=""></a>
        </div>
        <div class="text-col">
            <h3><?php echo $founder['nama']; ?></h3>
            <p><?php echo $founder['deskripsi']; ?></p>
            <ul class="team-social">
    <li><a href="https://www.facebook.com/profile.php?id=<?php echo $founder['fb']; ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
    <li><a href="https://www.instagram.com/<?php echo $founder['ig']; ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
    <li><a href="https://wa.me/<?php echo $founder['wa']; ?>" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
</ul>

        </div>
    </div>
</div>

                                <?php
                            }
                        } else {
                            echo "0 results";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div id="footer" class="footer-main">
        <div class="footer-box pad-top-70 pad-bottom-100">
            <div class="container">
                <div class="row">
                    <div class="footer-in-main">
                        <div class="footer-logo">
                            <div class="text-center">
                                <img src="images/logo.png" alt="" />
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="footer-box-a">
                                <h3>Tentang Kami</h3>
                                <p>Temukan kami di berbagai media social kami untuk mendapatkan informasi lebih lanjut.</p>
                                <ul class="socials-box footer-socials pull-left">
                                    <li>
                                        <a href="https://www.facebook.com/profile.php?id=100028724352214" target="_blank">
                                            <div class="social-circle-border"><i class="fa  fa-facebook"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://api.whatsapp.com/send/?phone=%2B6285669530929&text&type=phone_number&app_absent=0" target="_blank">
                                            <div class="social-circle-border"><i class="fa fa-whatsapp"></i></div>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/dennnis.s" target="_blank">
                                            <div class="social-circle-border"><i class="fa fa-instagram"></i></div>
                                        </a>
                                    </li>
                                </ul>

                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="footer-box-b">
        <h3>Resep Terbaru</h3>
        <ul>
            <?php
            $resep = [
                ['nama_makanan' => 'Pasta', 'gambar' => '1.png'],
                ['nama_makanan' => 'Nasi Goreng', 'gambar' => '2.png'],
                ['nama_makanan' => 'Salad Buah', 'gambar' => '3.png'],
                ['nama_makanan' => 'Rawon', 'gambar' => '4.png']
            ];

            foreach ($resep as $row) {
                echo '<li><a href="detail_makanan.php?nama_makanan=' . urlencode($row['nama_makanan']) . '">' . $row['nama_makanan'] . '</a></li>';
            }
            ?>
        </ul>
    </div>
  </div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="footer-box-c">
        <h3>Kontak kami</h3>
        <p>
            <i class="fa fa-whatsapp" aria-hidden="true"></i>
                <span><a href="https://wa.me/+6285669530929">+6285669530929</a></span>
        </p>
        <p>
            <i class="fa fa-envelope" aria-hidden="true"></i>
                <span><a href="https://www.gmail.com" target="_blank">ventinitygt@gmail.com</a></span>
        </p>
        <h3>Special Credit</h3>
        <p>
            <i class="fa fa-youtube" aria-hidden="true"></i>
                <span><a href="https://www.youtube.com/@devinahermawan" target="_blank">Devina Hermawan</a></span>
        </p>
    </div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
    <div class="footer-box-d">
        <h3>Copyright</h3>
             <ul>
                <li>
                    <p>OpenAi ChatGPT </p>
                    <p>Cookpad</p>
                    <p>Bootstrap</p>
                    <p>W3School</p>
                </li>
            </ul>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>